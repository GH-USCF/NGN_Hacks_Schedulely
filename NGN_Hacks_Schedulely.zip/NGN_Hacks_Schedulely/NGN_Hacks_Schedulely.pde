import controlP5.*; 
import javax.swing.JOptionPane;
import javax.swing.JColorChooser; // Imported for native color wheel dialog
import java.awt.Color;            // Imported for Java Color object conversions

// ==========================================
// MARKER ITEM CLASS
// ==========================================
class MarkerItem {
  public String label;
  public int itemColor; 

  public MarkerItem(String markerLabel, int markerColor) {
    this.label = markerLabel;
    this.itemColor = markerColor;
  }

  public int getColor() {
    return this.itemColor;
  }

  public String getLabel() {
    return this.label;
  }

  public void setLabel(String newLabel) {
    this.label = newLabel;
  }

  public void setColor(int newColor) {
    this.itemColor = newColor;
  }
}

// ==========================================
// 1. STATE MACHINE & GLOBAL VARIABLES
// ==========================================
enum State {
  MENU, APP, HELP
}

State currentState = State.MENU;

ArrayList<MarkerItem> markerList = new ArrayList<MarkerItem>();
int activePendingColor;
int selectedMarkerIndex = -1;

ControlP5 cp5;
Textfield Marker;

// Color Palette - using 0xFFRRGGBB hex format for Processing compatibility
int bgDark       = 0xFF0F172A; 
int cardBg       = 0xFF1E293B; 
int accentNeon   = 0xFF38BDF8; 
int textLight    = 0xFFF8FAFC; 
int textMuted    = 0xFF94A3B8; 
int deleteRed    = 0xFFEF4444; 
int customBtnCol = 0xFF00FF66; // Neon green for "C" custom color button

int[] presetColors = {
  0xFFFF3366, 0xFFFF9900, 0xFFFFD700, 0xFF00E676, 0xFF00E5FF, 
  0xFF3D5AFE, 0xFFD500F9, 0xFFFF5252, 0xFF00F5D4, 0xFFCCFF00
};

int colorIndex = 0; 

Button startBtn, helpBtn, backBtn, screenshotBtn;

// Flag to control single-frame screenshot export
boolean pendingScreenshot = false;

// ==========================================
// DATA STRUCTURE FOR PLACED SCHEDULE BLOCKS
// ==========================================
class ScheduleBlock {
  public int dayIndex;      
  public float startHour;   
  public float endHour;     
  public int blockColor;
  public String label;
  public boolean isUpper;   
  public boolean isPending; 

  public ScheduleBlock(int dayIndex, float startHour, float endHour, int blockColor, String label, boolean isUpper, boolean isPending) {
    this.dayIndex = dayIndex;
    this.startHour = startHour;
    this.endHour = endHour;
    this.blockColor = blockColor;
    this.label = label;
    this.isUpper = isUpper;
    this.isPending = isPending;
  }
}

ArrayList<ScheduleBlock> placedBlocks = new ArrayList<ScheduleBlock>();

// Grid Creation Dragging
boolean isDragging = false;
int dragDayIndex = -1;
float dragStartHour = 0.0f;
float dragCurrentHour = 0.0f;
boolean dragIsUpper = true;

// Grid Resizing
boolean isResizing = false;
int resizeEdge = 0; 
ScheduleBlock activeResizeBlock = null;

// Existing Block Dragging
boolean isBlockDragging = false;
ScheduleBlock activeDragBlock = null;
float blockDragOffsetStart = 0.0f; 
float blockDragDuration = 0.0f;
float initialMouseX = 0.0f;
float initialMouseY = 0.0f;
boolean blockPendingDeletion = false;
int pendingDeleteIndex = -1;

// ==========================================
// HELPER METHODS
// ==========================================
// Calculates dynamic text color (black vs white) based on background luminance
int getContrastingTextColor(int bgHex) {
  float r = red(bgHex);
  float g = green(bgHex);
  float b = blue(bgHex);
  
  // Perceptual relative brightness formula
  float luminance = (0.299f * r) + (0.587f * g) + (0.114f * b);
  
  return (luminance > 128.0f) ? color(0) : color(255);
}

int generatePresetColor() {
  int c = presetColors[colorIndex];
  colorIndex = (colorIndex + 1) % presetColors.length;
  return c;
}

void updateTextfieldColor() {
  if (Marker != null) {
    Marker.setColorForeground(accentNeon);
    Marker.setColorActive(accentNeon);
    Marker.setColorValue(accentNeon);
  }
}

int getActiveDrawingColor() {
  if (selectedMarkerIndex >= 0 && selectedMarkerIndex < markerList.size()) {
    MarkerItem item = markerList.get(selectedMarkerIndex);
    if (item != null) {
      return item.getColor();
    }
  }
  return activePendingColor;
}

String getActiveDrawingLabel() {
  if (selectedMarkerIndex >= 0 && selectedMarkerIndex < markerList.size()) {
    MarkerItem item = markerList.get(selectedMarkerIndex);
    if (item != null) {
      return item.getLabel();
    }
  }
  String currentText = Marker.getText().trim();
  return (currentText.length() > 0) ? currentText : "Pending...";
}

String truncateText(String str, float maxWidth) {
  if (textWidth(str) <= maxWidth) {
    return str;
  }
  String ellipsis = "...";
  String truncated = str;
  while (truncated.length() > 0 && textWidth(truncated + ellipsis) > maxWidth) {
    truncated = truncated.substring(0, truncated.length() - 1);
  }
  return truncated.length() > 0 ? (truncated + ellipsis) : "";
}

void syncPendingBlocksWithTextfield() {
  if (selectedMarkerIndex == -1 && Marker != null) {
    String currentText = Marker.getText().trim();
    String displayLabel = (currentText.length() > 0) ? currentText : "Pending...";
    for (ScheduleBlock block : placedBlocks) {
      if (block.isPending) {
        block.label = displayLabel;
      }
    }
  }
}

// Native JColorChooser dialog window with interactive color wheel
void openColorWheelDialog(int itemIndex) {
  MarkerItem item = markerList.get(itemIndex);
  
  // Convert Processing color (ARGB) to Java Color object
  int c = item.getColor();
  Color initialColor = new Color((c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF);
  
  // Launch native Swing JColorChooser window
  Color chosenColor = JColorChooser.showDialog(null, "Select Custom Color for " + item.getLabel(), initialColor);
  
  if (chosenColor != null) {
    // Convert selected Java Color back to Processing color integer
    int newColor = color(chosenColor.getRed(), chosenColor.getGreen(), chosenColor.getBlue());
    int oldColor = item.getColor();
    item.setColor(newColor);
    
    // Update all blocks associated with this label/color
    for (ScheduleBlock block : placedBlocks) {
      if (block.label.equalsIgnoreCase(item.getLabel()) || block.blockColor == oldColor) {
        block.blockColor = newColor;
      }
    }
    println("Updated color for marker '" + item.getLabel() + "' via Color Wheel.");
  }
}

// Dialog prompt to rename an existing selected marker and its blocks
void openRenameLabelDialog(int itemIndex) {
  MarkerItem item = markerList.get(itemIndex);
  String currentLabel = item.getLabel();
  
  String newLabelInput = JOptionPane.showInputDialog(null, "Enter a new name for this label:", "Rename Label", JOptionPane.PLAIN_MESSAGE, null, null, currentLabel) + "";
  
  if (newLabelInput != null && !newLabelInput.equals("null")) {
    String cleanedLabel = newLabelInput.trim();
    if (cleanedLabel.length() > 0 && !cleanedLabel.equals(currentLabel)) {
      item.setLabel(cleanedLabel);
      for (ScheduleBlock block : placedBlocks) {
        if (block.label.equalsIgnoreCase(currentLabel) || block.blockColor == item.getColor()) {
          block.label = cleanedLabel;
        }
      }
      println("Renamed marker '" + currentLabel + "' to: " + cleanedLabel);
    }
  }
}

// ==========================================
// 2. SETUP & INITIALIZATION
// ==========================================
void setup() {
  size(1280, 720); 
  smooth();
  textFont(createFont("SansSerif", 16));
  pixelDensity(1);
  
  activePendingColor = generatePresetColor();
  
  startBtn      = new Button(width/2 - 100, 310, 200, 50, "Launch App");
  helpBtn       = new Button(width/2 - 100, 380, 200, 50, "How It Works");
  backBtn       = new Button(40, 15, 100, 40, "← Back");
  screenshotBtn = new Button(width/2 - 90, 635, 180, 40, "📷 Export Image");
  
  cp5 = new ControlP5(this);
  
  Marker = (Textfield) cp5.addTextfield("userInput")
                           .setPosition(840, 110)
                           .setSize(240, 30)
                           .setFont(createFont("SansSerif", 24))
                           .setFocus(true)
                           .setColorBackground(cardBg)
                           .setColorCursor(accentNeon)
                           .setAutoClear(true);
                   
  updateTextfieldColor();
  Marker.getCaptionLabel().setText("").setColor(textMuted);
  updateControlP5Visibility();
}

// ==========================================
// 3. MAIN DRAW LOOP
// ==========================================
public void draw() {
  background(bgDark);
  cursor(ARROW);
  
  if (currentState == State.APP) {
    syncPendingBlocksWithTextfield();
  }
  
  switch (currentState) {
    case MENU:
      drawMenuState();
      break;
    case APP:
      drawAppState();
      break;
    case HELP:
      drawHelpState();
      break;
  }

  // --- SCREENSHOT CAPTURE ROUTINE ---
  if (pendingScreenshot) {
    String filename = "schedule-" + year() + "-" + month() + "-" + day() + "_" + hour() + minute() + second() + ".png";
    saveFrame("screenshots/" + filename);
    println("Screenshot saved successfully to: screenshots/" + filename);
    
    // Reset flag and restore UI elements
    pendingScreenshot = false;
    updateControlP5Visibility();
  }
}

// ==========================================
// 4. STATE SCREENS
// ==========================================
void drawMenuState() {
  textAlign(CENTER, CENTER);
  fill(textLight);
  textSize(48);
  text("Schedulely", width/2, 170);
  
  fill(accentNeon);
  textSize(20);
  text("Drag, color, and master your week at a glance.", width/2, 230);
  
  startBtn.display();
  helpBtn.display();
}

void drawAppState() {
  // Only render action buttons when NOT capturing a screenshot frame
  if (!pendingScreenshot) {
    backBtn.display();
    screenshotBtn.display();
  }
  
  fill(cardBg);
  stroke(accentNeon);
  strokeWeight(2);
  rect(180, 50, width - 360, height - 160, 12);
  
  strokeWeight(3);
  stroke(accentNeon);
  line(820, 60, 820, 600);
  
  // 1. SCHEDULE GRID
  String[] days = {"Mon.", "Tue.", "Wed.", "Thu.", "Fri.", "Sat.", "Sun."};
  float gridStartX = 280.0f;
  float gridEndX   = 760.0f;
  float hourWidth  = (gridEndX - gridStartX) / 12.0f;
  
  for (int d = 0; d < days.length; d++) {
    float dayY = 90.0f + (d * 80.0f);
    
    textAlign(CENTER, CENTER);
    fill(accentNeon);
    textSize(36);
    text(days[d], 230, dayY);
    
    strokeWeight(3);
    stroke(accentNeon);
    line(gridStartX, dayY, gridEndX, dayY);
    
    for (int h = 0; h <= 12; h++) {
      float tickX = gridStartX + (h * hourWidth);
      line(tickX, dayY - 20, tickX, dayY + 20);
    }
    
    fill(accentNeon);
    textSize(24);
    text("AM", 790, dayY - 20);
    text("PM", 790, dayY + 20);
    
    if (d != days.length - 1) {
      textSize(24);
      text("12   1    2    3    4    5    6    7    8    9   10   11", 500, dayY + 40);
    }
  }
  
  // 2. SIDEBAR HEADER
  textAlign(CENTER, CENTER);
  textSize(36);
  fill(textLight);
  text("Labels/Markers:", 960, 80);
  
  // 3. DISPLAY MARKERS, COLOR "C" & DELETE "X" BUTTONS
  float startY = 155.0f;
  float lineSpacing = 45.0f;
  int maxVisible = 10;
  
  int displayCount = min(markerList.size(), maxVisible);
  
  for (int i = 0; i < displayCount; i++) {
    int itemIndex = (int)(markerList.size() - 1 - i);
    MarkerItem item = markerList.get(itemIndex);
    
    float itemY = startY + (i * lineSpacing);
    
    boolean isSelected = (selectedMarkerIndex == itemIndex);
    
    boolean isCHovered    = (mouseX >= 835 && mouseX <= 860 && mouseY >= itemY && mouseY <= itemY + 30);
    boolean isPillHovered = (mouseX >= 865 && mouseX <= 1050 && mouseY >= itemY && mouseY <= itemY + 30);
    boolean isDeleteHovered = (mouseX >= 1055 && mouseX <= 1080 && mouseY >= itemY && mouseY <= itemY + 30);
    
    // --- [C] CUSTOM COLOR BUTTON (Neon Green) ---
    stroke(customBtnCol);
    fill(isCHovered ? customBtnCol : bgDark);
    strokeWeight(2);
    rect(835, itemY, 25, 30, 6);
    
    fill(isCHovered ? bgDark : customBtnCol);
    textSize(16);
    textAlign(CENTER, CENTER);
    text("C", 847, itemY + 14);
    
    // --- MARKER PILL ---
    int itemCol = item.getColor();
    stroke(itemCol);
    fill(isSelected ? itemCol : (isPillHovered ? color(red(itemCol), green(itemCol), blue(itemCol), 80) : bgDark));
    strokeWeight(isSelected ? 3 : 2);
    rect(865, itemY, 185, 30, 6);
    
    // Text color dynamically contrasts when selected
    fill(isSelected ? getContrastingTextColor(itemCol) : itemCol);
    textSize(18);
    textAlign(CENTER, CENTER);
    String displayPillText = truncateText(item.getLabel(), 170.0f);
    text(displayPillText, 957, itemY + 15);
    
    // --- [X] DELETE BUTTON ---
    stroke(deleteRed);
    fill(isDeleteHovered ? deleteRed : bgDark);
    strokeWeight(2);
    rect(1055, itemY, 25, 30, 6);
    
    fill(isDeleteHovered ? bgDark : deleteRed);
    textSize(18);
    text("✕", 1067, itemY + 14);
  }
  
  // 4. PLACED SCHEDULE BLOCKS
  float edgeHandleWidth = 6.0f;
  for (ScheduleBlock block : placedBlocks) {
    float dayY = 90.0f + (block.dayIndex * 80.0f);
    float blockX1 = gridStartX + (block.startHour * hourWidth);
    float blockX2 = gridStartX + (block.endHour * hourWidth);
    float blockY = block.isUpper ? (dayY - 20.0f) : dayY;
    float blockWidth = blockX2 - blockX1;
    
    if (!isDragging && !isResizing && !isBlockDragging) {
      if (mouseY >= blockY && mouseY <= blockY + 20) {
        if (abs(mouseX - blockX1) <= edgeHandleWidth || abs(mouseX - blockX2) <= edgeHandleWidth) {
          cursor(HAND);
        } else if (mouseX > blockX1 + edgeHandleWidth && mouseX < blockX2 - edgeHandleWidth) {
          cursor(MOVE);
        }
      }
    }
    
    fill(block.blockColor);
    stroke(textLight);
    strokeWeight(1);
    rect(blockX1, blockY, blockWidth, 20);
    
    // Dynamic text color based on light vs dark block color
    fill(getContrastingTextColor(block.blockColor));
    textSize(11);
    textAlign(CENTER, CENTER);
    
    if (blockWidth > 20) {
      String blockText = truncateText(block.label, blockWidth - 8.0f);
      if (blockText.length() > 0) {
        text(blockText, blockX1 + blockWidth/2.0f, blockY + 10.0f);
      }
    }
  }

  // 5. ACTIVE NEW GRID BLOCK DRAG PREVIEW
  if (isDragging) {
    float dayY = 90.0f + (dragDayIndex * 80.0f);
    float minH = min(dragStartHour, dragCurrentHour);
    float maxH = max(dragStartHour, dragCurrentHour);
    float blockX1 = gridStartX + (minH * hourWidth);
    float blockX2 = gridStartX + (maxH * hourWidth);
    float blockY = dragIsUpper ? (dayY - 20.0f) : dayY;
    
    int activeC = getActiveDrawingColor();
    fill(color(red(activeC), green(activeC), blue(activeC), 200));
    stroke(accentNeon);
    strokeWeight(2);
    rect(blockX1, blockY, max(blockX2 - blockX1, 20.0f), 20);
  }
}

void drawHelpState() {
  backBtn.display();
  textAlign(CENTER, TOP);
  fill(textLight);
  textSize(36);
  text("Instructions & Hour Reference", width/2, 20);
  
  // --- VISUAL GRID HOUR REFERENCE CONTAINER ---
  fill(cardBg);
  stroke(accentNeon);
  strokeWeight(2);
  rect(120, 65, 1040, 200, 12);
  
  textAlign(CENTER, CENTER);
  fill(accentNeon);
  textSize(20);
  text("24-Hour Timeline Mapping Reference", width/2, 85);
  
  float exGridX1 = 210.0f;
  float exGridX2 = 970.0f;
  float exWidth = (exGridX2 - exGridX1) / 12.0f;
  float exY = 160.0f;
  
  textAlign(RIGHT, CENTER);
  textSize(12);
  fill(accentNeon);
  text("AM Track →", exGridX1 - 10, exY - 10);
  text("PM Track →", exGridX1 - 10, exY + 10);
  
  strokeWeight(3);
  stroke(accentNeon);
  line(exGridX1, exY, exGridX2, exY);
  
  String[] hourLabels = {"12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
  for (int h = 0; h <= 12; h++) {
    float tickX = exGridX1 + (h * exWidth);
    line(tickX, exY - 22, tickX, exY + 22);
    
    textAlign(CENTER, CENTER);
    fill(textLight);
    textSize(12);
    text(hourLabels[h], tickX, exY + 34);
  }
  
  textAlign(LEFT, CENTER);
  fill(accentNeon);
  textSize(14);
  text("AM", exGridX2 + 10, exY - 10);
  text("PM", exGridX2 + 10, exY + 10);
  
  // Example Block Overlays using Processing hex notation
  float amX1 = exGridX1 + (8 * exWidth);
  float amX2 = exGridX1 + (11 * exWidth);
  fill(0xFFFF3366);
  stroke(textLight);
  strokeWeight(1);
  rect(amX1, exY - 20, amX2 - amX1, 20);
  fill(255);
  textSize(11);
  textAlign(CENTER, CENTER);
  text("8:00 AM - 11:00 AM", amX1 + (amX2 - amX1)/2.0f, exY - 10);
  
  float pmX1 = exGridX1 + (1 * exWidth);
  float pmX2 = exGridX1 + (5 * exWidth);
  fill(0xFF00E5FF);
  stroke(textLight);
  strokeWeight(1);
  rect(pmX1, exY, pmX2 - pmX1, 20);
  fill(0);
  textSize(11);
  textAlign(CENTER, CENTER);
  text("1:00 PM - 5:00 PM", pmX1 + (pmX2 - pmX1)/2.0f, exY + 10);
  
  fill(textMuted);
  textSize(15);
  textAlign(LEFT, TOP);
  float textY = 280.0f;
  
  text("• AM / PM Split: Each day row has an Upper Track (AM hours: 12 AM Midnight to 11 AM) and a Lower Track (PM hours: 12 PM Noon to 11 PM).\n" +
       "• Add Markers: Type a label into the input field and press ENTER. Markers are auto-assigned bright neon colors from a preset palette.\n" +
       "• Select Markers: Click a marker pill in the sidebar to activate it. Dragging on the grid will draw blocks with that active marker label & color.\n" +
       "• Rename Markers: Click an ALREADY SELECTED marker pill in the sidebar to open a dialog window and update its label across all blocks.\n" +
       "• Custom Colors: Click the green 'C' button beside any sidebar marker to open an interactive Color Wheel and set a custom color.\n" +
       "• Delete Markers: Click the red '✕' button beside any sidebar marker to permanently remove it and all of its placed schedule blocks.\n" +
       "• Draw Blocks: Click and drag across any day row to create a block. Drawing locks to half-hour intervals automatically.\n" +
       "• Resize Blocks: Hover over the left or right edge of a placed block until the hand cursor appears, then click and drag to resize.\n" +
       "• Move Blocks: Hover over the middle of a placed block until the move cursor appears, then drag it across the row or swap AM/PM tracks.\n" +
       "• Delete Blocks: Single-click the center of any placed schedule block on the grid without dragging to delete it instantly.\n" +
       "• Export Schedule: Click '📷 Export Image' at the bottom to save a high-resolution PNG snapshot directly to your 'screenshots' folder.", 120, textY);
}

// ==========================================
// 5. STATE MANAGEMENT & CONTROLP5
// ==========================================
void changeState(State newState) {
  currentState = newState;
  updateControlP5Visibility();
}

void updateControlP5Visibility() {
  if (currentState == State.APP) {
    Marker.show();
  } else {
    Marker.hide();
  }
}

public void userInput(String text) {
  String cleanedText = text.trim();
  if (cleanedText.length() > 0) {
    markerList.add(new MarkerItem(cleanedText, activePendingColor));
    
    for (ScheduleBlock block : placedBlocks) {
      if (block.isPending) {
        block.label = cleanedText;
        block.isPending = false;
      }
    }
    
    activePendingColor = generatePresetColor();
    updateTextfieldColor();
    
    if (markerList.size() > 10) {
      markerList.remove(markerList.size() - 1);
      println("List cap reached (10 max). Most recent entry was discarded.");
    } else {
      println("Saved Entry: " + cleanedText);
    }
  }
}

void takeScreenshot() {
  pendingScreenshot = true;
  Marker.hide();
}

// ==========================================
// 6. INPUT HANDLERS & MOUSE EVENTS
// ==========================================
public void mousePressed() {
  if (currentState == State.MENU) {
    if (startBtn.isHovered()) changeState(State.APP);
    if (helpBtn.isHovered())  changeState(State.HELP);
  } 
  else if (currentState == State.APP) {
    if (backBtn.isHovered()) {
      changeState(State.MENU);
      return;
    }
    
    if (screenshotBtn.isHovered()) {
      takeScreenshot();
      return;
    }
    
    // SIDEBAR INTERACTION
    float startY = 155.0f;
    float lineSpacing = 45.0f;
    int maxVisible = 10;
    int displayCount = min(markerList.size(), maxVisible);
    
    boolean clickedMarkerArea = false;
    
    for (int i = 0; i < displayCount; i++) {
      float itemY = startY + (i * lineSpacing);
      int itemIndex = (int)(markerList.size() - 1 - i);
      
      // Custom Color "C" Button - Opens JColorChooser Color Wheel
      if (mouseX >= 835 && mouseX <= 860 && mouseY >= itemY && mouseY <= itemY + 30) {
        openColorWheelDialog(itemIndex);
        return;
      }
      
      // Delete "X" Button
      if (mouseX >= 1055 && mouseX <= 1080 && mouseY >= itemY && mouseY <= itemY + 30) {
        MarkerItem removedItem = markerList.remove(itemIndex);
        
        for (int j = placedBlocks.size() - 1; j >= 0; j--) {
          ScheduleBlock b = placedBlocks.get(j);
          if (b.label.equalsIgnoreCase(removedItem.getLabel()) || b.blockColor == removedItem.getColor()) {
            placedBlocks.remove(j);
          }
        }
        
        if (selectedMarkerIndex == itemIndex) {
          selectedMarkerIndex = -1;
        } else if (selectedMarkerIndex > itemIndex) {
          selectedMarkerIndex--;
        }
        println("Deleted Marker and its blocks: " + removedItem.getLabel());
        return;
      }
      
      // Marker Pill
      if (mouseX >= 865 && mouseX <= 1050 && mouseY >= itemY && mouseY <= itemY + 30) {
        clickedMarkerArea = true;
        if (selectedMarkerIndex == itemIndex) {
          openRenameLabelDialog(itemIndex);
        } else {
          selectedMarkerIndex = itemIndex;
          println("Selected Marker: " + markerList.get(selectedMarkerIndex).getLabel());
        }
        return;
      }
    }
    
    boolean clickedTextfield = (mouseX >= 840 && mouseX <= 1080 && mouseY >= 110 && mouseY <= 140);
    
    // BLOCK RESIZE / MOVE / DELETE ON GRID
    float gridStartX = 280.0f;
    float gridEndX   = 760.0f;
    float hourWidth  = (gridEndX - gridStartX) / 12.0f;
    float edgeBuffer = 8.0f;
    
    boolean clickedGridBlock = false;
    
    for (int i = placedBlocks.size() - 1; i >= 0; i--) {
      ScheduleBlock b = placedBlocks.get(i);
      float dayY = 90.0f + (b.dayIndex * 80.0f);
      float blockX1 = gridStartX + (b.startHour * hourWidth);
      float blockX2 = gridStartX + (b.endHour * hourWidth);
      float blockY = b.isUpper ? (dayY - 20.0f) : dayY;
      
      if (mouseY >= blockY && mouseY <= blockY + 20) {
        if (abs(mouseX - blockX1) <= edgeBuffer) {
          isResizing = true;
          resizeEdge = -1;
          activeResizeBlock = b;
          return;
        }
        else if (abs(mouseX - blockX2) <= edgeBuffer) {
          isResizing = true;
          resizeEdge = 1;
          activeResizeBlock = b;
          return;
        }
        else if (mouseX > blockX1 + edgeBuffer && mouseX < blockX2 - edgeBuffer) {
          activeDragBlock = b;
          blockDragDuration = b.endHour - b.startHour;
          
          float clampedX = constrain(mouseX, gridStartX, gridEndX);
          float clickHour = (clampedX - gridStartX) / hourWidth;
          blockDragOffsetStart = clickHour - b.startHour;
          
          initialMouseX = mouseX;
          initialMouseY = mouseY;
          blockPendingDeletion = true;
          pendingDeleteIndex = i;
          return;
        }
      }
    }
    
    // START NEW GRID DRAG INTERACTION
    float edgeLeniency = 15.0f;
    boolean clickedOnGrid = false;
    for (int d = 0; d < 7; d++) {
      float dayY = 90.0f + (d * 80.0f);
      
      if (mouseY >= dayY - 20 && mouseY <= dayY + 20 && mouseX >= (gridStartX - edgeLeniency) && mouseX <= (gridEndX + edgeLeniency)) {
        clickedOnGrid = true;
        
        if (selectedMarkerIndex == -1) {
          println("Cannot create block: Please select an existing label/marker from the sidebar first.");
          return;
        }

        if (markerList.size() >= 10 && selectedMarkerIndex == -1) {
          println("Cannot create block: Maximum of 10 markers reached. Select an existing marker or delete one.");
          return;
        }

        isDragging = true;
        dragDayIndex = d;
        dragIsUpper = (mouseY < dayY);
        
        float clampedX = constrain(mouseX, gridStartX, gridEndX);
        float rawHour = (clampedX - gridStartX) / hourWidth;
        dragStartHour = round(rawHour * 2.0f) / 2.0f;
        dragCurrentHour = dragStartHour;
        break;
      }
    }
    
    if (!clickedMarkerArea && !clickedTextfield && !clickedGridBlock && !clickedOnGrid) {
      if (selectedMarkerIndex != -1) {
        selectedMarkerIndex = -1;
        println("Deselected active marker.");
      }
    }
  }
  else if (currentState == State.HELP) {
    if (backBtn.isHovered()) changeState(State.MENU);
  }
}

void mouseDragged() {
  if (currentState == State.APP) {
    float gridStartX = 280.0f;
    float gridEndX   = 760.0f;
    float hourWidth  = (gridEndX - gridStartX) / 12.0f;
    
    if (isResizing && activeResizeBlock != null) {
      float constrainedX = constrain(mouseX, gridStartX, gridEndX);
      float snappedHour = round(((constrainedX - gridStartX) / hourWidth) * 2.0f) / 2.0f;
      
      if (resizeEdge == -1) {
        float newStart = min(snappedHour, activeResizeBlock.endHour - 0.5f);
        boolean overlap = false;
        for (ScheduleBlock b : placedBlocks) {
          if (b != activeResizeBlock && b.dayIndex == activeResizeBlock.dayIndex && b.isUpper == activeResizeBlock.isUpper) {
            if (newStart < b.endHour && activeResizeBlock.endHour > b.startHour) {
              overlap = true;
              break;
            }
          }
        }
        if (!overlap) activeResizeBlock.startHour = newStart;
      } 
      else if (resizeEdge == 1) {
        float newEnd = max(snappedHour, activeResizeBlock.startHour + 0.5f);
        boolean overlap = false;
        for (ScheduleBlock b : placedBlocks) {
          if (b != activeResizeBlock && b.dayIndex == activeResizeBlock.dayIndex && b.isUpper == activeResizeBlock.isUpper) {
            if (activeResizeBlock.startHour < b.endHour && newEnd > b.startHour) {
              overlap = true;
              break;
            }
          }
        }
        if (!overlap) activeResizeBlock.endHour = newEnd;
      }
    } 
    else if (activeDragBlock != null) {
      float dragDistance = dist(mouseX, mouseY, initialMouseX, initialMouseY);
      
      if (dragDistance > 2.0f) {
        isBlockDragging = true;
        blockPendingDeletion = false; 
      }
      
      if (isBlockDragging) {
        float constrainedX = constrain(mouseX, gridStartX, gridEndX);
        float mouseHour = (constrainedX - gridStartX) / hourWidth;
        
        float proposedStart = mouseHour - blockDragOffsetStart;
        proposedStart = round(proposedStart * 2.0f) / 2.0f;
        proposedStart = constrain(proposedStart, 0.0f, 12.0f - blockDragDuration);
        float proposedEnd = proposedStart + blockDragDuration;
        
        float dayY = 90.0f + (activeDragBlock.dayIndex * 80.0f);
        boolean proposedUpper = (mouseY < dayY);
        
        boolean overlap = false;
        for (ScheduleBlock b : placedBlocks) {
          if (b != activeDragBlock && b.dayIndex == activeDragBlock.dayIndex && b.isUpper == proposedUpper) {
            if (proposedStart < b.endHour && proposedEnd > b.startHour) {
              overlap = true;
              break;
            }
          }
        }
        
        if (!overlap) {
          activeDragBlock.startHour = proposedStart;
          activeDragBlock.endHour = proposedEnd;
          activeDragBlock.isUpper = proposedUpper;
        }
      }
    }
    else if (isDragging) {
      float constrainedX = constrain(mouseX, gridStartX, gridEndX);
      float rawHour = (constrainedX - gridStartX) / hourWidth;
      dragCurrentHour = round(rawHour * 2.0f) / 2.0f;
    }
  }
}

void mouseReleased() {
  if (currentState == State.APP) {
    if (isResizing) {
      isResizing = false;
      activeResizeBlock = null;
      resizeEdge = 0;
    } 
    else if (activeDragBlock != null) {
      if (blockPendingDeletion && pendingDeleteIndex >= 0 && pendingDeleteIndex < placedBlocks.size()) {
        placedBlocks.remove(pendingDeleteIndex);
        println("Removed block via click: " + activeDragBlock.label);
      }
      
      isBlockDragging = false;
      activeDragBlock = null;
      blockPendingDeletion = false;
      pendingDeleteIndex = -1;
    }
    else if (isDragging) {
      float startH = min(dragStartHour, dragCurrentHour);
      float endH   = max(dragStartHour, dragCurrentHour);
      
      if (endH == startH) {
        endH = min(startH + 0.5f, 12.0f);
      }
      
      boolean overlaps = false;
      for (ScheduleBlock b : placedBlocks) {
        if (b.dayIndex == dragDayIndex && b.isUpper == dragIsUpper) {
          if (startH < b.endHour && endH > b.startHour) {
            overlaps = true;
            break;
          }
        }
      }
      
      if (!overlaps) {
        String activeLabel = getActiveDrawingLabel();
        int activeColor = getActiveDrawingColor();
        boolean pendingState = (selectedMarkerIndex == -1);
        
        placedBlocks.add(new ScheduleBlock(dragDayIndex, startH, endH, activeColor, activeLabel, dragIsUpper, pendingState));
      } else {
        println("Placement cancelled: Overlaps existing entry.");
      }
      
      isDragging = false;
      dragDayIndex = -1;
    }
  }
}

// ==========================================
// BUTTON CLASS
// ==========================================
class Button {
  public float x, y, w, h;
  public String label;
  
  public Button(float x, float y, float w, float h, String label) {
    this.x = x; 
    this.y = y; 
    this.w = w; 
    this.h = h; 
    this.label = label;
  }
  
  public boolean isHovered() {
    return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
  }
  
  public void display() {
    pushStyle();
    rectMode(CORNER);
    if (isHovered()) {
      fill(accentNeon); 
      stroke(textLight); 
      strokeWeight(2); 
      cursor(HAND);
    } else {
      fill(cardBg); 
      stroke(accentNeon); 
      strokeWeight(1.5f);
    }
    rect(x, y, w, h, 8);
    textAlign(CENTER, CENTER);
    fill(isHovered() ? bgDark : textLight);
    textSize(16);
    text(label, x + w/2.0f, y + h/2.0f - 2.0f);
    popStyle();
  }

  // Renamed from main to execute (and removed static) to prevent Java/Processing class conflicts
  public void execute() {
    // Optional click handler logic
  }
}
